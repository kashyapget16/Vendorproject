import React, { createContext, useContext, useState, useEffect } from 'react';

const MockDataContext = createContext();

export const useMockData = () => useContext(MockDataContext);

const initialData = {
  user: null, // { role: 'admin' | 'vendor', vendorId?: string, name: string }
  vendors: [
    { id: 'v1', name: 'Acme Corp', status: 'Active', contact: 'john@acme.com', rating: 4.8 },
    { id: 'v2', name: 'Global Tech', status: 'Pending', contact: 'jane@global.com', rating: 0 },
    { id: 'v3', name: 'Stark Industries', status: 'Inactive', contact: 'tony@stark.com', rating: 4.9 },
  ],
  products: [
    { id: 'p1', name: 'Widget A', sku: 'WDG-001', category: 'Hardware', price: 10.0 },
    { id: 'p2', name: 'Gadget B', sku: 'GDG-002', category: 'Electronics', price: 25.5 },
  ],
  pos: [
    { id: 'po1', poNumber: 'PO-1001', vendorId: 'v1', status: 'Pending', date: '2026-04-10', amount: 500 },
    { id: 'po2', poNumber: 'PO-1002', vendorId: 'v1', status: 'Accepted', date: '2026-04-12', amount: 1500 },
    { id: 'po3', poNumber: 'PO-1003', vendorId: 'v2', status: 'Fulfilled', date: '2026-04-01', amount: 200 },
  ],
  invoices: [
    { id: 'inv1', invoiceNumber: 'INV-2001', poId: 'po2', vendorId: 'v1', status: 'Pending', amount: 1500, date: '2026-04-15' },
    { id: 'inv2', invoiceNumber: 'INV-2002', poId: 'po3', vendorId: 'v2', status: 'Approved', amount: 200, date: '2026-04-05' },
  ],
  shipments: [
    { id: 'sh1', poId: 'po2', tracking: 'TRK992831', status: 'In Transit', carrier: 'FedEx' }
  ],
  payments: [
    { id: 'pay1', invoiceId: 'inv2', amount: 200, status: 'Paid', date: '2026-04-08' }
  ]
};

export const MockDataProvider = ({ children }) => {
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('vendorPortalData');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return initialData;
      }
    }
    return initialData;
  });

  useEffect(() => {
    localStorage.setItem('vendorPortalData', JSON.stringify(data));
  }, [data]);

  const login = (role, vendorId = null) => {
    setData(prev => ({ ...prev, user: { role, vendorId, name: role === 'admin' ? 'Admin User' : 'Vendor User' } }));
  };

  const logout = () => {
    setData(prev => ({ ...prev, user: null }));
  };

  // Vendor Functions
  const addVendor = (vendor) => {
    setData(prev => ({ ...prev, vendors: [...prev.vendors, { ...vendor, id: 'v' + Date.now(), status: 'Pending', rating: 0 }] }));
  };

  const updateVendorStatus = (id, status) => {
    setData(prev => ({
      ...prev,
      vendors: prev.vendors.map(v => v.id === id ? { ...v, status } : v)
    }));
  };

  // PO Functions
  const addPO = (po) => {
    setData(prev => ({ ...prev, pos: [...prev.pos, { ...po, id: 'po' + Date.now(), poNumber: 'PO-' + Math.floor(Math.random()*10000), status: 'Pending' }] }));
  };

  const updatePOStatus = (id, status) => {
    setData(prev => ({
      ...prev,
      pos: prev.pos.map(p => p.id === id ? { ...p, status } : p)
    }));
  };

  // Invoice Functions
  const addInvoice = (invoice) => {
    setData(prev => ({ ...prev, invoices: [...prev.invoices, { ...invoice, id: 'inv' + Date.now(), status: 'Pending' }] }));
  };

  const updateInvoiceStatus = (id, status) => {
    setData(prev => ({
      ...prev,
      invoices: prev.invoices.map(i => i.id === id ? { ...i, status } : i)
    }));
  };

  // Product Functions
  const addProduct = (product) => {
     setData(prev => ({ ...prev, products: [...prev.products, { ...product, id: 'p' + Date.now() }] }));
  };

  const value = {
    ...data,
    login,
    logout,
    addVendor,
    updateVendorStatus,
    addPO,
    updatePOStatus,
    addInvoice,
    updateInvoiceStatus,
    addProduct,
    setData
  };

  return (
    <MockDataContext.Provider value={value}>
      {children}
    </MockDataContext.Provider>
  );
};
