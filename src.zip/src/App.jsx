import { Routes, Route, Navigate } from 'react-router-dom';
import { useMockData } from './context/MockDataContext';

// Layouts
import AdminLayout from './layouts/AdminLayout';
import VendorLayout from './layouts/VendorLayout';

// Auth Pages
import Login from './pages/auth/Login';
import VendorSignup from './pages/auth/VendorSignup';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import VendorApprovals from './pages/admin/VendorApprovals';
import VendorManagement from './pages/admin/VendorManagement';
import ProductCatalog from './pages/admin/ProductCatalog';
import POCreation from './pages/admin/POCreation';
import InvoiceApproval from './pages/admin/InvoiceApproval';
import PaymentTracking from './pages/admin/PaymentTracking';

// Vendor Pages
import VendorDashboard from './pages/vendor/VendorDashboard';
import VendorApprovalStatus from './pages/vendor/VendorApprovalStatus';
import POManagement from './pages/vendor/POManagement';
import ShipmentHandling from './pages/vendor/ShipmentHandling';
import InvoiceSubmission from './pages/vendor/InvoiceSubmission';
import VendorPaymentTracking from './pages/vendor/VendorPaymentTracking';
import BarcodeView from './pages/vendor/BarcodeView';

function App() {
  const { user, vendors } = useMockData();

  if (!user) {
    return (
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/vendor-signup" element={<VendorSignup />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  }

  if (user.role === 'admin') {
    return (
      <Routes>
        <Route element={<AdminLayout />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/vendors/approvals" element={<VendorApprovals />} />
          <Route path="/admin/vendors/manage" element={<VendorManagement />} />
          <Route path="/admin/catalog" element={<ProductCatalog />} />
          <Route path="/admin/po" element={<POCreation />} />
          <Route path="/admin/invoices" element={<InvoiceApproval />} />
          <Route path="/admin/payments" element={<PaymentTracking />} />
          <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
        </Route>
      </Routes>
    );
  }

  if (user.role === 'vendor') {
    const vendor = vendors.find(v => v.id === user.vendorId);
    if (!vendor || vendor.status !== 'Active') {
      return (
        <Routes>
          <Route path="/vendor/status" element={<VendorApprovalStatus vendor={vendor} />} />
          <Route path="*" element={<Navigate to="/vendor/status" replace />} />
        </Routes>
      );
    }

    return (
      <Routes>
        <Route element={<VendorLayout />}>
          <Route path="/vendor/dashboard" element={<VendorDashboard />} />
          <Route path="/vendor/po" element={<POManagement />} />
          <Route path="/vendor/shipments" element={<ShipmentHandling />} />
          <Route path="/vendor/invoices" element={<InvoiceSubmission />} />
          <Route path="/vendor/payments" element={<VendorPaymentTracking />} />
          <Route path="/vendor/catalog" element={<BarcodeView />} />
          <Route path="*" element={<Navigate to="/vendor/dashboard" replace />} />
        </Route>
      </Routes>
    );
  }

  return null;
}

export default App;
