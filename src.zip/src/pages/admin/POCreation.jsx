import React, { useState } from 'react';
import { useMockData } from '../../context/MockDataContext';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Label } from '../../components/ui/Label';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '../../components/ui/Table';
import { Plus, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function POCreation() {
  const { vendors, products, addPO } = useMockData();
  const navigate = useNavigate();
  const activeVendors = vendors.filter(v => v.status === 'Active');
  
  const [vendorId, setVendorId] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [lineItems, setLineItems] = useState([{ productId: '', quantity: 1, rate: 0 }]);

  const handleProductChange = (index, productId) => {
    const product = products.find(p => p.id === productId);
    const newItems = [...lineItems];
    newItems[index] = { ...newItems[index], productId, rate: product ? product.price : 0 };
    setLineItems(newItems);
  };

  const handleQuantityChange = (index, quantity) => {
    const newItems = [...lineItems];
    newItems[index] = { ...newItems[index], quantity: parseInt(quantity) || 0 };
    setLineItems(newItems);
  };

  const addLineItem = () => {
    setLineItems([...lineItems, { productId: '', quantity: 1, rate: 0 }]);
  };

  const removeLineItem = (index) => {
    setLineItems(lineItems.filter((_, i) => i !== index));
  };

  const totalAmount = lineItems.reduce((acc, item) => acc + (item.quantity * item.rate), 0);

  const handleSubmit = () => {
    if (!vendorId || !deliveryDate || lineItems.length === 0 || !lineItems[0].productId) {
      alert("Please fill all required fields.");
      return;
    }
    
    addPO({
      vendorId,
      date: deliveryDate,
      amount: totalAmount,
      items: lineItems
    });
    
    navigate('/admin/dashboard');
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight text-slate-900">Create Purchase Order</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>PO Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Vendor</Label>
              <select 
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                value={vendorId}
                onChange={(e) => setVendorId(e.target.value)}
              >
                <option value="">Select Vendor...</option>
                {activeVendors.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label>Delivery Date</Label>
              <Input 
                type="date" 
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold">Line Items</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lineItems.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <select 
                        className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        value={item.productId}
                        onChange={(e) => handleProductChange(index, e.target.value)}
                      >
                        <option value="">Select Product...</option>
                        {products.map(p => (
                          <option key={p.id} value={p.id}>{p.name} ({p.sku})</option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell>
                      <Input 
                        type="number" 
                        min="1" 
                        className="h-9" 
                        value={item.quantity}
                        onChange={(e) => handleQuantityChange(index, e.target.value)}
                      />
                    </TableCell>
                    <TableCell>${item.rate.toFixed(2)}</TableCell>
                    <TableCell>${(item.quantity * item.rate).toFixed(2)}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="text-red-500" onClick={() => removeLineItem(index)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <Button variant="outline" size="sm" onClick={addLineItem}>
              <Plus className="mr-2 h-4 w-4" /> Add Item
            </Button>
            
            <div className="flex justify-end pt-4 border-t">
              <div className="text-xl font-bold">
                Total: ${totalAmount.toFixed(2)}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="justify-end border-t p-6">
          <Button variant="outline" className="mr-2" onClick={() => navigate(-1)}>Cancel</Button>
          <Button onClick={handleSubmit}>Create PO</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
