import React, { useState } from 'react';
import { useMockData } from '../../context/MockDataContext';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '../../components/ui/Table';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';

export default function PaymentTracking() {
  const { invoices, payments, setData } = useMockData();
  
  // Find approved invoices that don't have a full payment yet (simplified to any payment for demo)
  const unpaidInvoices = invoices.filter(i => 
    i.status === 'Approved' && !payments.some(p => p.invoiceId === i.id)
  );

  const handleReleasePayment = (invoice) => {
    setData(prev => ({
      ...prev,
      payments: [...prev.payments, {
        id: 'pay' + Date.now(),
        invoiceId: invoice.id,
        amount: invoice.amount,
        status: 'Paid',
        date: new Date().toISOString().split('T')[0]
      }]
    }));
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight text-slate-900">Payment Tracking</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Invoices Pending Payment</CardTitle>
        </CardHeader>
        <CardContent>
          {unpaidInvoices.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              No pending payments.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {unpaidInvoices.map((inv) => (
                  <TableRow key={inv.id}>
                    <TableCell className="font-medium">{inv.invoiceNumber}</TableCell>
                    <TableCell>${inv.amount.toFixed(2)}</TableCell>
                    <TableCell>{inv.date}</TableCell>
                    <TableCell><Badge variant="warning">Pending Payment</Badge></TableCell>
                    <TableCell className="text-right">
                      <Button size="sm" onClick={() => handleReleasePayment(inv)}>
                        Release Payment
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
             <div className="text-center py-8 text-slate-500">No payment history.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Payment ID</TableHead>
                  <TableHead>Invoice ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map(p => (
                  <TableRow key={p.id}>
                    <TableCell>{p.id}</TableCell>
                    <TableCell>{invoices.find(i => i.id === p.invoiceId)?.invoiceNumber || p.invoiceId}</TableCell>
                    <TableCell>{p.date}</TableCell>
                    <TableCell>${p.amount.toFixed(2)}</TableCell>
                    <TableCell><Badge variant="success">{p.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
