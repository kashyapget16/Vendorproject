import React from 'react';
import { useMockData } from '../../context/MockDataContext';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Users, ShoppingCart, FileText, CreditCard, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';

export default function AdminDashboard() {
  const { vendors, pos, invoices, payments } = useMockData();
  const navigate = useNavigate();

  const activeVendors = vendors.filter(v => v.status === 'Active').length;
  const pendingVendors = vendors.filter(v => v.status === 'Pending').length;
  const activePOs = pos.filter(p => p.status === 'Pending' || p.status === 'Accepted').length;
  const pendingInvoices = invoices.filter(i => i.status === 'Pending').length;
  const totalPayments = payments.reduce((acc, curr) => acc + curr.amount, 0);

  const poData = [
    { name: 'Week 1', POs: 4 },
    { name: 'Week 2', POs: 3 },
    { name: 'Week 3', POs: 7 },
    { name: 'Week 4', POs: 5 },
  ];

  const invoiceData = [
    { name: 'Approved', value: invoices.filter(i => i.status === 'Approved').length },
    { name: 'Pending', value: invoices.filter(i => i.status === 'Pending').length },
    { name: 'Rejected', value: invoices.filter(i => i.status === 'Rejected').length },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Dashboard</h1>
      </div>

      {pendingVendors > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center">
            <Clock className="text-yellow-600 mr-3 h-5 w-5" />
            <span className="text-yellow-800 font-medium">You have {pendingVendors} vendor(s) waiting for approval.</span>
          </div>
          <Button variant="outline" size="sm" className="bg-white" onClick={() => navigate('/admin/vendors/approvals')}>
            Review Now
          </Button>
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Active Vendors</CardTitle>
            <Users className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeVendors}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Active POs</CardTitle>
            <ShoppingCart className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activePOs}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Pending Invoices</CardTitle>
            <FileText className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingInvoices}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Payments Released</CardTitle>
            <CreditCard className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalPayments.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>PO Trend (Weekly)</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={poData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="POs" stroke="#3b82f6" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Invoice Status</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={invoiceData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
