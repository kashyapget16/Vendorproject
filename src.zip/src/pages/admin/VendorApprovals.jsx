import React, { useState } from 'react';
import { useMockData } from '../../context/MockDataContext';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '../../components/ui/Table';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Check, X } from 'lucide-react';

export default function VendorApprovals() {
  const { vendors, updateVendorStatus } = useMockData();
  const pendingVendors = vendors.filter(v => v.status === 'Pending');
  
  const [remarks, setRemarks] = useState({});

  const handleApprove = (id) => {
    updateVendorStatus(id, 'Active');
  };

  const handleReject = (id) => {
    if (!remarks[id]) {
      alert("Remarks are mandatory for rejection.");
      return;
    }
    updateVendorStatus(id, 'Rejected');
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight text-slate-900">Vendor Onboarding Approvals</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Pending Registrations</CardTitle>
        </CardHeader>
        <CardContent>
          {pendingVendors.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              No pending vendor registrations.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Company Name</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Remarks</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingVendors.map((vendor) => (
                  <TableRow key={vendor.id}>
                    <TableCell className="font-medium">{vendor.name}</TableCell>
                    <TableCell>{vendor.contact}</TableCell>
                    <TableCell>
                      <input 
                        type="text" 
                        placeholder="Rejection remarks..."
                        className="border rounded px-2 py-1 text-sm w-full"
                        value={remarks[vendor.id] || ''}
                        onChange={(e) => setRemarks({...remarks, [vendor.id]: e.target.value})}
                      />
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button size="sm" variant="outline" className="text-green-600 border-green-200 hover:bg-green-50" onClick={() => handleApprove(vendor.id)}>
                        <Check className="h-4 w-4 mr-1" /> Approve
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={() => handleReject(vendor.id)}>
                        <X className="h-4 w-4 mr-1" /> Reject
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
