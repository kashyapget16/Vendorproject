import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMockData } from '../../context/MockDataContext';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Label } from '../../components/ui/Label';
import { CheckCircle2, ChevronLeft, Building2, User, Landmark, FileText } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function VendorSignup() {
  const { addVendor, login, vendors } = useMockData();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    registrationNo: '',
    contact: '',
    phone: '',
    bankName: '',
    accountNumber: '',
  });

  const handleNext = () => setStep(s => Math.min(4, s + 1));
  const handlePrev = () => setStep(s => Math.max(1, s - 1));

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    // Mock save and login
    const newVendorId = 'v' + Date.now();
    addVendor({
      id: newVendorId,
      name: formData.name,
      contact: formData.contact,
      status: 'Pending',
      rating: 0
    });
    // Find the newly created vendor in context later, or just log them in immediately.
    // We log them in so they see the Pending screen.
    login('vendor', newVendorId);
    navigate('/vendor/status');
  };

  const steps = [
    { id: 1, title: 'Company Details', icon: Building2 },
    { id: 2, title: 'Contact', icon: User },
    { id: 3, title: 'Bank Info', icon: Landmark },
    { id: 4, title: 'Documents', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-xl">
        <CardHeader>
          <div className="flex items-center mb-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')} className="-ml-2 mr-2">
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              <CardTitle className="text-2xl">Vendor Registration</CardTitle>
              <CardDescription>Partner with us and grow your business</CardDescription>
            </div>
          </div>
          
          {/* Progress Indicator */}
          <div className="flex justify-between items-center mt-6 relative">
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-slate-200 -z-10 rounded"></div>
            <div 
              className="absolute left-0 top-1/2 transform -translate-y-1/2 h-1 bg-primary -z-10 rounded transition-all duration-300"
              style={{ width: `${((step - 1) / 3) * 100}%` }}
            ></div>
            {steps.map(s => {
              const Icon = s.icon;
              const isActive = step >= s.id;
              return (
                <div key={s.id} className="flex flex-col items-center">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors",
                    isActive ? "bg-primary border-primary text-primary-foreground" : "bg-white border-slate-300 text-slate-400"
                  )}>
                    {step > s.id ? <CheckCircle2 className="w-6 h-6" /> : <Icon className="w-5 h-5" />}
                  </div>
                  <span className={cn(
                    "text-xs mt-2 font-medium",
                    isActive ? "text-slate-900" : "text-slate-500"
                  )}>{s.title}</span>
                </div>
              )
            })}
          </div>
        </CardHeader>
        
        <CardContent className="pt-6">
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
              <div className="space-y-2">
                <Label htmlFor="name">Company Name</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="e.g. Acme Corp" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="registrationNo">Registration Number</Label>
                <Input id="registrationNo" name="registrationNo" value={formData.registrationNo} onChange={handleChange} placeholder="e.g. 12345678" />
              </div>
            </div>
          )}
          
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
              <div className="space-y-2">
                <Label htmlFor="contact">Primary Email</Label>
                <Input id="contact" name="contact" type="email" value={formData.contact} onChange={handleChange} placeholder="john@acme.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} placeholder="+1 234 567 8900" />
              </div>
            </div>
          )}
          
          {step === 3 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
              <div className="space-y-2">
                <Label htmlFor="bankName">Bank Name</Label>
                <Input id="bankName" name="bankName" value={formData.bankName} onChange={handleChange} placeholder="e.g. Chase" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input id="accountNumber" name="accountNumber" value={formData.accountNumber} onChange={handleChange} placeholder="•••• •••• •••• 1234" />
              </div>
            </div>
          )}
          
          {step === 4 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
              <div className="space-y-2">
                <Label htmlFor="docs">Upload Trade License / Tax Documents</Label>
                <Input id="docs" type="file" className="cursor-pointer" />
                <p className="text-xs text-muted-foreground mt-1">PDF or JPG up to 5MB.</p>
              </div>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-between border-t p-6 mt-4">
          <Button variant="outline" onClick={handlePrev} disabled={step === 1}>
            Back
          </Button>
          {step < 4 ? (
            <Button onClick={handleNext} disabled={(step === 1 && !formData.name) || (step === 2 && !formData.contact)}>
              Continue
            </Button>
          ) : (
            <Button onClick={handleSubmit}>
              Submit Registration
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
