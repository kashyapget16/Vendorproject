import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useMockData } from '../../context/MockDataContext';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { PackageSearch, Users, ArrowRight } from 'lucide-react';

export default function Login() {
  const { login } = useMockData();
  const navigate = useNavigate();

  const handleLogin = (role) => {
    if (role === 'admin') {
      login('admin');
      navigate('/admin/dashboard');
    } else {
      // For demo, just log in as vendor 'v1'
      login('vendor', 'v1');
      navigate('/vendor/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <div className="h-12 w-12 bg-primary rounded-xl flex items-center justify-center shadow-lg">
              <PackageSearch className="text-black h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">VendorPortal</h1>
          </div>
          <h2 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            Modernize your <span className="text-primary">supply chain</span>.
          </h2>
          <p className="text-lg text-slate-600">
            A complete ERP module for vendor onboarding, purchase orders, shipments, and invoice tracking.
          </p>
        </div>

        <Card className="w-full shadow-2xl border-0 ring-1 ring-slate-200">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-2xl text-center">Sign In</CardTitle>
            <CardDescription className="text-center">
              Choose your role to access the portal demo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              className="w-full h-14 text-lg justify-between px-6"
              onClick={() => handleLogin('admin')}
            >
              <div className="flex items-center">
                <Users className="mr-3 h-5 w-5" />
                Login as Admin
              </div>
              <ArrowRight className="h-5 w-5 opacity-70" />
            </Button>

            <Button
              variant="outline"
              className="w-full h-14 text-lg justify-between px-6 border-slate-300"
              onClick={() => handleLogin('vendor')}
            >
              <div className="flex items-center text-slate-700">
                <PackageSearch className="mr-3 h-5 w-5" />
                Login as Vendor
              </div>
              <ArrowRight className="h-5 w-5 opacity-70" />
            </Button>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4 border-t border-slate-100 mt-4 pt-6">
            <div className="text-sm text-center text-slate-500">
              New vendor?
            </div>
            <Button variant="ghost" className="w-full" onClick={() => navigate('/vendor-signup')}>
              Register your company
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
